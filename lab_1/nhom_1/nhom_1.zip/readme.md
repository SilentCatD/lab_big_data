  

<div style="text-align: center">

    <span style="font-size: 3em; font-weight: 700; font-family: Consolas">

        Lab 01 <br>

		Building Recommendation Systems

    </span>

    <br><br>

    <span style="">

        A assignment for <code>CSC14114</code>  Big Data Application @ 19KHMT

    </span>

</div>

  
  

## Collaborators (nhom 1)

- `19127519` **Nguyễn Ngọc Phước** ([Nguyễn Ngọc Phước](https://github.com/SilentCatD))

- `19127523` **Đặng Nguyễn Minh Quân** ([Đặng Nguyễn Minh Quân](https://github.com/quainhan1110))

## Instructors

- `HCMUS` **Đoàn Đình Toàn** ([@ddtoan](ddtoan18@clc.fitus.edu.vn))

- `HCMUS` **Nguyễn Ngọc Thảo** ([@nnthao](nnthao@fit.hcmus.edu.vn))

---

<div style="page-break-after: always"></div>
## Collab link to 2 notebook:

- [Google drive to both files](https://drive.google.com/drive/folders/1rtSM4YfD_MXHewAEjduhCV8xIRussA6x?usp=sharing)
- [Link to K-Nearest Neighbors Recommendation.ipynb](https://drive.google.com/file/d/1jf08IuxIUoZInoxxKsWMqyZz0Vgzvw26/view?usp=sharing)
- [Link to MovieLens 1M Dataset.ipynb](https://drive.google.com/file/d/1Q0FJsiHzJxbjaONZmRBcYkx0x7aXS6Vs/view?usp=sharing)